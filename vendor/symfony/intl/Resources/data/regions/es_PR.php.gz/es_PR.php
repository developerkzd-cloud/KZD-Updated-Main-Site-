<?php

return [
    'UserAssignedNames' => [],
    'Names' => [
        'UM' => 'Islas menores alejadas de EE. UU.',
    ],
];
