<?php

return [
    'Names' => [
        'Africa/Bujumbura' => 'hora de África central (Buyumbura)',
        'Africa/Dar_es_Salaam' => 'hora de África oriental (Dar es-Salaam)',
        'America/Rio_Branco' => 'Hora de Acre (Rio Branco)',
        'Asia/Almaty' => 'hora de Kazajistán (Almatý)',
        'Asia/Aqtobe' => 'hora de Kazajistán (Aktobé)',
        'Asia/Atyrau' => 'hora de Kazajistán (Atirau)',
        'Atlantic/Stanley' => 'hora de Islas Malvinas (Stanley)',
        'Indian/Christmas' => 'hora de la isla de Navidad',
        'Pacific/Easter' => 'hora de Isla de Pascua',
        'Pacific/Honolulu' => 'hora estándar de Hawái-Aleutianas (Honolulu)',
        'Pacific/Tarawa' => 'hora de las Islas Gilbert (Tarawa)',
        'Pacific/Wake' => 'hora de la Isla Wake',
    ],
    'Meta' => [],
];
